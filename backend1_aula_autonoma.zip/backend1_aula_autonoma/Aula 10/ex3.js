const alunos = ["Anna", "Bruno", "Carlos", "Enzo"];

console.log("Lista de Alunos");
console.log(alunos);

console.log(`primeiro aluno: ${alunos[0]}`);
console.log(`Segundo aluno: ${alunos[1]}`);

alunos.push("Cecilia");
alunos.push("Heitor");
alunos.splice

console.log(`Segundo aluno: ${alunos[2]}`);
console.log(`Ultimo aluno: ${alunos[alunos.length- 1]}`);
console.log(`Quantidade de alunos: ${alunos.length}`);

// acrescentar mais 2 nomes ao array
// mostrar o terceiro aluno
// mostrar o ultimo aluno

// const alunos = ["Anna", "Bruno", "Carlos", "Enzo", "Juan", "Rizzo"];

// console.log(`Terceito aluno: ${alunos[3]}`);
// console.log(`Último aluno: ${alunos[5]}`);