const alunos = ["Anna", "Bruno", "Carlos", "Rizzo"];
console.log(`O primeiro aluno da lista é: ${alunos[0]}`);
console.log(`Quantidade de alunos: ${alunos.length}`);