const moradores =["Anna", "Bruno", "Carlos"];

console.log(moradores[0]);